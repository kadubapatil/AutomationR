package com.company;

import javax.swing.*;

public class Practice{
    private float f;
    private int b;
    private boolean c;

    public void setF(float f) {
        this.f = f;
    }

    public float getF() {
        return f;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getB() {
        return b;
    }

    public void setC(boolean c) {
        this.c = c;
    }

    public boolean isC() {
        return c;
    }

    public static void main(String[] args) {
        Practice P=new Practice();
        P.setB(50);
        System.out.println(P.getB());
        P.setC(false);
        System.out.println(P.isC());
        P.setF(10.5f);
        System.out.println(P.getF());
    }
}



