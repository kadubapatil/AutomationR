package com.company;

public class Human {
   private String name;
   private int age;
private float f;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public static void main(String[] args) {
        Human h=new Human();
        h.setName("Kaduba");
        System.out.println(h.getName());
        h.setAge(29);
        System.out.println(h.getAge());
    }


}
