package com.company;

public class Variables {

    int a=20;   //instance variable
    static int b;
    static {
        b=30;
        System.out.println("static block");
    }

    public static void main (String [] args ){
        Variables v=new Variables();

        int a;//local variable

        a=30;

        System.out.println(a);

        System.out.println(v.a);
        System.out.println(b);
    }
}
