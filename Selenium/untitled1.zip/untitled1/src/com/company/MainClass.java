package com.company;
public class MainClass {
    public static void main(String[] args) {
        Human h=new Human();


    }
}
