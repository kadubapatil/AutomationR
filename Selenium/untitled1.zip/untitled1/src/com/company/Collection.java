package com.company;

import java.util.ArrayList;

public class Collection {
    public static void main(String[] args) {
        ArrayList arrayList=new ArrayList();

        arrayList.add("Hello");
        arrayList.add("Good Morning");
        arrayList.add("Good Morning");
        arrayList.add("How Are You");
        arrayList.add("where are you");
        arrayList.add(20);
        arrayList.add(5.5f);
        arrayList.add(null);
        arrayList.add(true);

            System.out.println(arrayList.get(2));
            System.out.println(arrayList.remove(1));
            System.out.println(arrayList.size());

            for (Object o:arrayList){
                System.out.println(o);
            }

        }

}
