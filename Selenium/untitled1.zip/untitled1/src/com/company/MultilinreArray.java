package com.company;

public class MultilinreArray {

    public static void main(String[] args) {
        int[][] s= new int[][]{{20,30,40,50,},{30,60,30,70}};

        String[]x=new String[]{"KADUBA","VISHVAS","GOPAL"};

        for (int i=0; i<=s.length-1; i++);

        System.out.println(x[2]);
        System.out.println(s.length);

    }
}
