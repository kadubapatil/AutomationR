
class A2{
    int a=20;
    void method(){
        System.out.println("Number 20");

    }
}
class A1 extends A2{
    void method(){
        System.out.println("Number");
    }
}


public class FinalKeyword {

    public static void main(String[] args) {
        A2 A=new A2();
        A.method();




    }
}
