public class AutoboxingUnboxing {
    public static void main(String[] args) {

        int b=50;
        boolean c=false;
        Integer i=b;    //Autoboxing
        Boolean B=c;


        int d=i;         //Unboxing
        boolean B1=B;
        System.out.println(i);
        System.out.println(B);
        System.out.println(d);
    }
}
