public class Variable2 {

    int a=20;                // instance variable

    static double d=20.5;    //static variable

    public static void main(String[] args) {

        boolean b =true; // local variable

        Variable2 v =new Variable2();

        System.out.println(v.a);
        System.out.println(d);
        System.out.println(b);
    }
}
