class parent{

    public void pen(){
        System.out.println("Gelpen");

    }
}
class child extends parent  {
    public void pencile(){

        System.out.println("Natraj");
    }
}

public class Inheritance{
    public static void main(String[] args) {
        child c=new child();
        c.pen();
        c.pencile();

    }
}
