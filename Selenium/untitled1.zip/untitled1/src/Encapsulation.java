public class Encapsulation {
    private String name;
    private int a;
    private float f;

    public void setName(String name ) {
        this.name =name;
    }

    public void setA(int a) {
        this.a = a;
    }

    public void setF(float f) {
        this.f =f;
    }

    public String getName() {
        return name;
    }
    public int getA() {
        return a;
    }
    public float getF() {
        return f;
    }
}














