public class SplitStringExample {

    public static void main(String[] args) {


        String a="What are you doing man";
        String c="Digital Partner";

        String[] b=a.split("");
        String[] d=c.split("");

        for (String str:b){
            System.out.println(str);

            for (String str1:d){
                System.out.println(str1);
            }
        }

    }

}
