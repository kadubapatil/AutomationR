public class Static {

    int a=10;
    static int b=30;

    public static void main(String[] args) {
        Static s=new Static();
        s.method2();
        Static.method1();

    }
    static void method1()
    {
        System.out.println("Static Method "+b);
    }
    void method2()

        {
            System.out.println("Non Static Method " +a);

    }

}
