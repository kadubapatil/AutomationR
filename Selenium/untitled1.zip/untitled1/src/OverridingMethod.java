 class OverridingMethod1{
    public void method2(){
        System.out.println("Method of class OverridingMethod1 ");
        }

    }
     class OverridingMethod2 extends OverridingMethod1{

       public void method2(){
           System.out.println("Method of class OverridingMethod2");
       }

        }

        public class OverridingMethod {
            public static void main(String[] args) {
                OverridingMethod1 o=new OverridingMethod1();
                o.method2();
                OverridingMethod2 s=new OverridingMethod2();
                s.method2();

            }

        }


