public class Test {
    int a;
    int b;

    public void method1(int a,int b)
    {
         this.a=a;
         this.b=b;
    }

    public static void main(String[] args) {
        Test t=new Test();

        t.method1(10,15);

        System.out.println(t.a);

        System.out.println(t.b);
    }
}
