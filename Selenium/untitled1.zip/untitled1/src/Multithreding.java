public class Multithreding implements Runnable{

    public void run()
    {
        System.out.println("value of i is "+ Thread.currentThread().getId());
    }

    public static void main(String[] args) {

        int a=12;

        for (int i=0;i<a;i++){

            Thread t1=new Thread(new Multithreding());

            t1.start();
        }


    }
}