

    class A{
  void show(){
      System.out.println("hello world");
  }
    }

    class B extends A{
    void show() {
        super.show();
        System.out.println("hii brother");
    }
}
    public class SuperKeyword {

    public static void main(String[] args) {
    B b=new B();
    b.show();


    }

}

