public class Arrays {


    public static void main(String[] args) {

        int [] a={10,20,30,40,50}; //a=5

        for( int b:a)


        System.out.print(b+" ");
        System.out.print(a  [3]);

    }
}
