    class Test1{
    public void method1(){

        System.out.println("method 1");

    }
}

    class Test2 extends Test1{

    public void method1(){
        super.method1();

        System.out.println("method 2");

    }
}
        public class Demo {
    public static void main(String[] args) {
              Test1 t=new Test2();
              t.method1();
            }

}
