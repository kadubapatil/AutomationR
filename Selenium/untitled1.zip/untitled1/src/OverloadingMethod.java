public class OverloadingMethod {

    int a;
    int b;
    public void addition()
    {
     a=20;
     b=10;
        System.out.println(a+b);
    }
    public void addition(int c,int d)
    {
        int a=c;
        int b=d;
        System.out.println(a+b);

    }
    public void addition(int e,int f,int g)
    {
        System.out.println(e+f+g);
    }
    public void addition(int a,double b){
        System.out.println(a+b);
    }

    public static void main(String[] args) {
        OverloadingMethod o=new OverloadingMethod();
        o.addition();
        o.addition(50,60);
        o.addition(10,30,40);
        o.addition(20,10.5);


    }
}
