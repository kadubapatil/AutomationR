class Upcasting{
     public void method(){

         System.out.println("Upcasting Method");
     }
}
class Upcasting2 extends Upcasting{

    public void method1() {


        System.out.println("Upcasting Method2");
    }
    public class Casting {
    }
    public static void main(String[] args) {
        Upcasting u=new Upcasting2();   //Upcasting
        Upcasting2 U=(Upcasting2)u;     //Downcasting

        U.method1();

        U.method();
    }

}
