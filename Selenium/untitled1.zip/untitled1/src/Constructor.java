 class Constructor {

    int a;
    String name;
    Constructor()
    {
        a=20; name="Hello";
    }
  void method1 ()
  {


        System.out.println(a+ " "+name );
  }


        public static void main(String[] args){
            Constructor c=new Constructor();
            c.method1();

    }
}

