import javax.swing.*;

public class ThrowAndThrows {
    public  static void method()throws NullPointerException{

        System.out.println("Hello Method");

        throw new NullPointerException();
    }
    public static void main(String[] args) {
        try {
           method();
        }catch (NullPointerException e){

            System.out.println("Null pointer exception");

        }
        System.out.println("Hello");
    }
}
