public class WriteOnly {
    public static void main(String[] args) {
        Encapsulation E=new Encapsulation();

       E.setName("KADUBA");
       E.setF(20.5f);
       E.setA(35);


        System.out.println(E.getName());
        System.out.println(E.getA());
        System.out.println(E.getF());
    }

}
