public class StringExample {
    public static void main(String[] args) {
        StringBuffer sb=new StringBuffer("What are you doing today");


        sb.append(" Man");
        System.out.println(sb);


        sb.insert(0,"kaduba");
        System.out.println(sb);

        sb.reverse();
        System.out.println(sb);


    }
}
