public interface InterfacePractice {
    void method();
    void method2();

    abstract  class demo implements InterfacePractice {

      public void method() {
          System.out.println("Hello, how are you");
      }

        }
        class show extends demo{
            @Override
            public void method2() {
                System.out.println("hello");
            }
        }

    public static void main(String[] args) {
        show s= new show();
        s.method();
        s.method2();
    }
}
