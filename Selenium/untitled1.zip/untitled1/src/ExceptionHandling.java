public class ExceptionHandling {
    public static void main(String[] args) {

        System.out.println("main method");

        int a=10,b=0,c;

        try {
            c=a/b;//10/0
            System.out.println(c);
        }catch (ArithmeticException e) {
           e.printStackTrace();
            System.out.println(e);
        }


        System.out.println("main method1");
    }

}
