public class ReverseStringExample {

    public static void main(String[] args) {
        String s=("Kaduba Patil");

        String s1=("My Name Is K ");

        ReverseStringExample r=new ReverseStringExample();

        for (int i=s.length()-1;i>=0;i--){
            System.out.print(s.charAt(i));
            System.out.print(s1.charAt(i));
        }

    }
}
