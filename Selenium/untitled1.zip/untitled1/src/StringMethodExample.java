public class StringMethodExample {
    public static void main(String[] args) {
        String a="KADUBA";
        String b="patil";
        String c="   Prashant   ";

        System.out.println(a.toLowerCase());
        System.out.println(b.toUpperCase());


        System.out.println(a. concat(b));
        System.out.println(a.length());
        System.out.println(b.length());


        System.out.println(c.trim());
        System.out.println(a.charAt(3));


        System.out.println(a.equals(b));
        System.out.println(b.replace('a','s'));
    }



}
